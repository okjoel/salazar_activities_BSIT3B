"""
URL configuration for blockchain project.

The `urlpatterns` list routes URLs to views.
"""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from credentials_app.views import home  # Import the home view

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),                 # Root URL -> home view
    path('', include('credentials_app.urls')),  # Include app URLs
    path('api/', include('credentials_app.urls')),
]

# Serve media files locally when DEBUG=True (development)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Serve static files locally when DEBUG=False
if not settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
