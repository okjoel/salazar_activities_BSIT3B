# views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django import forms
import hashlib

from .models import User, Credential, VerificationLog
from django.contrib.auth.forms import UserCreationForm
from django.views.decorators.http import require_POST

# DRF imports
from rest_framework import viewsets, permissions
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .serializers import UserSerializer, CredentialSerializer, VerificationLogSerializer

# --------- FORMS -----------

class CustomUserCreationForm(UserCreationForm):
    role = forms.ChoiceField(
        choices=User.ROLE_CHOICES,
        widget=forms.Select(attrs={'class': 'mt-1 block w-full'})
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'role')


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'w-full border p-2 rounded'}),
            'email': forms.EmailInput(attrs={'class': 'w-full border p-2 rounded'}),
        }


class CredentialIssueForm(forms.ModelForm):
    class Meta:
        model = Credential
        fields = ['student', 'title', 'file']
        widgets = {
            'student': forms.Select(attrs={'class': 'w-full p-2 border rounded'}),
            'title': forms.TextInput(attrs={'class': 'w-full p-2 border rounded'}),
            'file': forms.ClearableFileInput(attrs={'class': 'w-full p-2 border rounded'}),
        }


# --------- VIEWS -----------

def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'home.html')


def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful.')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'auth/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'auth/login.html')


@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def dashboard_view(request):
    user = request.user
    if user.is_superuser:
        return redirect('admin_dashboard')
    elif user.role == 'student':
        credentials = Credential.objects.filter(student=user)
        return render(request, 'dashboard/student.html', {'credentials': credentials})
    elif user.role == 'institution':
        issued_credentials = Credential.objects.filter(issued_by=user)
        issued_count = issued_credentials.count()
        return render(request, 'dashboard/institution.html', {
            'issued_credentials': issued_credentials,
            'issued_count': issued_count
        })
    elif user.role == 'employer':
        verification_logs = VerificationLog.objects.filter(verifier=user).order_by('-verified_at')[:10]
        return render(request, 'dashboard/employer.html', {'verification_logs': verification_logs})
    else:
        messages.error(request, "Invalid user role.")
        return redirect('logout')


@login_required
def profile_view(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated.')
            return redirect('profile')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = ProfileForm(instance=request.user)
    return render(request, 'auth/profile.html', {'form': form})


@login_required
def issue_credential(request):
    if request.user.role != 'institution':
        messages.error(request, "You don't have permission to issue credentials.")
        return redirect('dashboard')

    if request.method == 'POST':
        form = CredentialIssueForm(request.POST, request.FILES)
        if form.is_valid():
            credential = form.save(commit=False)
            credential.issued_by = request.user

            if credential.file:
                file_data = credential.file.read()
                credential.file.seek(0)
                credential.hash_value = hashlib.sha256(file_data).hexdigest()
            else:
                credential.hash_value = ''

            credential.save()
            messages.success(request, 'Credential issued successfully.')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = CredentialIssueForm()
    return render(request, 'dashboard/issue.html', {'form': form})


@login_required
def verify_credential(request):
    if request.method == 'POST':
        hash_value = request.POST.get('hash_value', '').strip()
        try:
            credential = Credential.objects.get(hash_value=hash_value)
            VerificationLog.objects.create(credential=credential, verifier=request.user, is_valid=True)
            return render(request, 'dashboard/employer.html', {'result': credential})
        except Credential.DoesNotExist:
            VerificationLog.objects.create(credential=None, verifier=request.user, is_valid=False)
            return render(request, 'dashboard/employer.html', {'result': 'Invalid hash. No credential found.'})
    return redirect('dashboard')


# --------- ADMIN DASHBOARD -----------

@login_required
def admin_dashboard(request):
    if not request.user.is_superuser:
        return redirect('dashboard')
    users = User.objects.exclude(username=request.user.username)
    return render(request, 'dashboard/admin.html', {'users': users})


@login_required
@require_POST
def delete_user(request, user_id):
    if not request.user.is_superuser:
        return redirect('dashboard')
    user = get_object_or_404(User, id=user_id)
    user.delete()
    messages.success(request, 'User deleted.')
    return redirect('admin_dashboard')


@login_required
def add_user(request):
    if not request.user.is_superuser:
        return redirect('dashboard')

    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'User added.')
            return redirect('admin_dashboard')
    else:
        form = CustomUserCreationForm()
    return render(request, 'dashboard/add_user.html', {'form': form})

