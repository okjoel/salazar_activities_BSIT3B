from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.throttling import UserRateThrottle, AnonRateThrottle
from rest_framework.exceptions import PermissionDenied
from django.contrib.auth import authenticate
from django.views.decorators.csrf import csrf_exempt  # ⬅️ Import this
from django.utils.decorators import method_decorator  # For class-based views if ever needed

from .models import User, Credential, VerificationLog
from .serializers import (
    RegisterSerializer,
    CredentialSerializer,
    UserSerializer,
    CredentialVerifySerializer,
    VerificationLogSerializer,
)

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

class CredentialRateThrottle(UserRateThrottle):
    rate = '10/min'

class LoginRateThrottle(AnonRateThrottle):
    rate = '5/min'

# ✅ Exempt from CSRF
@csrf_exempt
@api_view(['POST'])
@permission_classes([AllowAny])
@throttle_classes([LoginRateThrottle])
def api_register(request):
    serializer = RegisterSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        tokens = get_tokens_for_user(user)
        return Response({"user": UserSerializer(user).data, "tokens": tokens}, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# ✅ Exempt from CSRF
@csrf_exempt
@api_view(['POST'])
@permission_classes([AllowAny])
@throttle_classes([LoginRateThrottle])
def api_login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(request, username=username, password=password)
    if user is not None:
        tokens = get_tokens_for_user(user)
        return Response({"user": UserSerializer(user).data, "tokens": tokens}, status=status.HTTP_200_OK)
    return Response({"detail": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def api_user_profile(request):
    return Response(UserSerializer(request.user).data)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
@throttle_classes([CredentialRateThrottle])
def api_issue_credential(request):
    if request.user.role != 'institution':
        return Response({'detail': 'Only institutions can issue credentials.'}, status=status.HTTP_403_FORBIDDEN)
    serializer = CredentialSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        serializer.save(issued_by=request.user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
@throttle_classes([CredentialRateThrottle])
def api_verify_credential(request):
    serializer = CredentialVerifySerializer(data=request.data)
    if serializer.is_valid():
        hash_value = serializer.validated_data['hash_value']
        try:
            credential = Credential.objects.get(hash_value=hash_value)
            result = {
                'is_valid': True,
                'credential': CredentialSerializer(credential).data
            }
        except Credential.DoesNotExist:
            result = {'is_valid': False}

        VerificationLog.objects.create(
            verifier=request.user,
            hash_value=hash_value,
            is_valid=result.get('is_valid', False)
        )
        return Response(result)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

class CredentialViewSet(viewsets.ModelViewSet):
    queryset = Credential.objects.all()
    serializer_class = CredentialSerializer
    permission_classes = [IsAuthenticated]
    throttle_classes = [CredentialRateThrottle]

    def perform_create(self, serializer):
        if self.request.user.role != 'institution':
            raise PermissionDenied("Only institutions can issue credentials.")
        serializer.save(issued_by=self.request.user)

    def get_queryset(self):
        user = self.request.user
        if user.role == 'institution':
            return Credential.objects.filter(issued_by=user)
        elif user.role == 'student':
            return Credential.objects.filter(student=user)
        return Credential.objects.none()

class VerificationLogViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = VerificationLog.objects.all()
    serializer_class = VerificationLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return VerificationLog.objects.filter(verifier=self.request.user)
