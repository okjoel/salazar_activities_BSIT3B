from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    ROLE_CHOICES = [
        ('student', 'Student'),
        ('institution', 'Institution'),
        ('employer', 'Employer'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='student')

    def __str__(self):
        return self.username


class Credential(models.Model):
    issued_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='issued_credentials')
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='credentials')
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='credentials/')
    hash_value = models.CharField(max_length=64, unique=True)

    issued_at = models.DateTimeField(auto_now_add=True)  # NO default here!

    def __str__(self):
        return f"Credential '{self.title}' issued to {self.student.username}"


class VerificationLog(models.Model):
    credential = models.ForeignKey(Credential, on_delete=models.SET_NULL, null=True, blank=True)
    verifier = models.ForeignKey(User, on_delete=models.CASCADE)
    verified_at = models.DateTimeField(auto_now_add=True)
    is_valid = models.BooleanField(default=False)

    def __str__(self):
        return f"Verification by {self.verifier.username} on {self.verified_at} - Valid: {self.is_valid}"
