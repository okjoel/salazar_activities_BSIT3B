from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Credential


class CustomUserCreationForm(UserCreationForm):
    role = forms.ChoiceField(
        choices=User.ROLE_CHOICES,
        widget=forms.Select(attrs={'class': 'mt-1 block w-full'})
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'role')


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'w-full border p-2 rounded'}),
            'email': forms.EmailInput(attrs={'class': 'w-full border p-2 rounded'}),
        }


class CredentialIssueForm(forms.ModelForm):
    class Meta:
        model = Credential
        fields = ['student', 'title', 'file']
        widgets = {
            'student': forms.Select(attrs={'class': 'w-full p-2 border rounded'}),
            'title': forms.TextInput(attrs={'class': 'w-full p-2 border rounded'}),
            'file': forms.ClearableFileInput(attrs={'class': 'w-full p-2 border rounded'}),
        }
