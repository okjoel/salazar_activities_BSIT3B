from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from . import views
from .api_views import UserViewSet, CredentialViewSet, VerificationLogViewSet

router = DefaultRouter()
router.register(r'api/users', UserViewSet, basename='api-users')
router.register(r'api/credentials', CredentialViewSet, basename='api-credentials')
router.register(r'api/verification-logs', VerificationLogViewSet, basename='api-verification-logs')

urlpatterns = [
    # Web routes
    path('', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('profile/', views.profile_view, name='profile'),
    path('issue/', views.issue_credential, name='issue_credential'),
    path('verify/', views.verify_credential, name='verify_credential'),

    # Admin dashboard and user management
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-dashboard/add-user/', views.add_user, name='admin_add_user'),
    path('admin-dashboard/delete-user/<int:user_id>/', views.delete_user, name='admin_delete_user'),

    # API routes from router
    path('', include(router.urls)),

    # JWT Authentication endpoints
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
