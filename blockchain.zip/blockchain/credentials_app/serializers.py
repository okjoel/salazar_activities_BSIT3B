# credentials_app/serializers.py
from rest_framework import serializers
from .models import User, Credential, VerificationLog

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'role']

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'role']

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            role=validated_data['role']
        )
        return user

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

class CredentialSerializer(serializers.ModelSerializer):
    student = UserSerializer(read_only=True)
    issued_by = UserSerializer(read_only=True)
    file_url = serializers.SerializerMethodField()

    class Meta:
        model = Credential
        fields = ['id', 'student', 'title', 'file', 'file_url', 'hash_value', 'issued_by', 'issued_at']
        read_only_fields = ['hash_value', 'issued_by', 'issued_at']

    def get_file_url(self, obj):
        request = self.context.get('request')
        if obj.file and request:
            return request.build_absolute_uri(obj.file.url)
        return None

class VerificationLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = VerificationLog
        fields = '__all__'

class CredentialVerifySerializer(serializers.Serializer):
    hash_value = serializers.CharField()
